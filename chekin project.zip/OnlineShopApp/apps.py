from django.apps import AppConfig


class OnlineshopappConfig(AppConfig):
    name = 'OnlineShopApp'
